/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { motion } from 'motion/react';
import { 
  Leaf, 
  Calendar, 
  MapPin, 
  Phone, 
  Clock, 
  ChevronRight, 
  Star,
  CheckCircle2,
  Menu,
  X
} from 'lucide-react';

// --- Components ---

const Navbar = () => {
  const [isOpen, setIsOpen] = React.useState(false);

  return (
    <nav className="fixed w-full z-50 bg-ayurveda-cream/80 backdrop-blur-md border-b border-ayurveda-olive/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-20 items-center">
          <div className="flex items-center gap-2">
            <Leaf className="text-ayurveda-olive w-8 h-8" />
            <span className="font-serif text-2xl font-semibold tracking-tight">AyurVeda</span>
          </div>
          
          <div className="hidden md:flex items-center gap-8">
            <a href="#about" className="text-sm font-medium hover:text-ayurveda-olive transition-colors">About</a>
            <a href="#services" className="text-sm font-medium hover:text-ayurveda-olive transition-colors">Services</a>
            <a href="#testimonials" className="text-sm font-medium hover:text-ayurveda-olive transition-colors">Testimonials</a>
            <a href="#contact" className="bg-ayurveda-olive text-white px-6 py-2 rounded-full text-sm font-medium hover:bg-ayurveda-olive/90 transition-all">
              Book Consultation
            </a>
          </div>

          <div className="md:hidden">
            <button onClick={() => setIsOpen(!isOpen)} className="p-2">
              {isOpen ? <X /> : <Menu />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {isOpen && (
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="md:hidden bg-ayurveda-cream border-b border-ayurveda-olive/10 px-4 py-6 flex flex-col gap-4"
        >
          <a href="#about" onClick={() => setIsOpen(false)} className="text-lg font-serif">About</a>
          <a href="#services" onClick={() => setIsOpen(false)} className="text-lg font-serif">Services</a>
          <a href="#testimonials" onClick={() => setIsOpen(false)} className="text-lg font-serif">Testimonials</a>
          <a href="#contact" onClick={() => setIsOpen(false)} className="bg-ayurveda-olive text-white px-6 py-3 rounded-full text-center font-medium">
            Book Consultation
          </a>
        </motion.div>
      )}
    </nav>
  );
};

const Hero = () => {
  return (
    <section className="relative pt-32 pb-20 lg:pt-48 lg:pb-32 overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
          >
            <span className="inline-block py-1 px-4 rounded-full bg-ayurveda-olive/10 text-ayurveda-olive text-xs font-semibold uppercase tracking-widest mb-6">
              Ancient Wisdom for Modern Life
            </span>
            <h1 className="text-6xl lg:text-8xl font-serif leading-[0.9] mb-8">
              Restore Your <span className="serif-italic text-ayurveda-terracotta">Natural</span> Balance
            </h1>
            <p className="text-lg text-ayurveda-ink/70 max-w-lg mb-10 leading-relaxed">
              Experience the profound healing power of traditional Ayurveda. Our personalized treatments and holistic approach help you achieve lasting wellness and inner peace.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <button className="bg-ayurveda-olive text-white px-8 py-4 rounded-full text-lg font-medium hover:bg-ayurveda-olive/90 transition-all flex items-center justify-center gap-2 group">
                Start Your Journey <ChevronRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </button>
              <button className="border border-ayurveda-olive/20 px-8 py-4 rounded-full text-lg font-medium hover:bg-ayurveda-olive/5 transition-all">
                View Our Services
              </button>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 1, delay: 0.2 }}
            className="relative"
          >
            <div className="relative z-10">
              <img 
                src="https://picsum.photos/seed/ayurveda-hero/800/1000" 
                alt="Ayurvedic Treatment" 
                className="pill-image w-full max-w-md mx-auto shadow-2xl"
                referrerPolicy="no-referrer"
              />
            </div>
            {/* Decorative elements */}
            <div className="absolute top-1/2 -right-12 w-64 h-64 bg-ayurveda-terracotta/10 rounded-full blur-3xl -z-10" />
            <div className="absolute -bottom-12 -left-12 w-48 h-48 bg-ayurveda-olive/10 rounded-full blur-3xl -z-10" />
          </motion.div>
        </div>
      </div>
    </section>
  );
};

const Services = () => {
  const services = [
    {
      title: "Panchakarma Detox",
      description: "A comprehensive detoxification process to cleanse the body of deep-seated toxins and restore vitality.",
      icon: <Leaf className="w-6 h-6" />,
      image: "https://picsum.photos/seed/panchakarma/400/500"
    },
    {
      title: "Abhyanga Massage",
      description: "Traditional warm oil massage tailored to your dosha, promoting lymphatic drainage and relaxation.",
      icon: <Star className="w-6 h-6" />,
      image: "https://picsum.photos/seed/massage/400/500"
    },
    {
      title: "Dosha Consultation",
      description: "Expert analysis of your unique constitution to provide personalized diet and lifestyle recommendations.",
      icon: <CheckCircle2 className="w-6 h-6" />,
      image: "https://picsum.photos/seed/consult/400/500"
    }
  ];

  return (
    <section id="services" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-20">
          <h2 className="text-4xl lg:text-5xl font-serif mb-6">Our Healing Services</h2>
          <p className="text-ayurveda-ink/60 leading-relaxed">
            We offer a range of traditional treatments designed to harmonize the mind, body, and spirit. Each therapy is customized to your specific needs.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-12">
          {services.map((service, index) => (
            <motion.div
              key={index}
              whileHover={{ y: -10 }}
              className="group cursor-pointer"
            >
              <div className="mb-6 overflow-hidden rounded-[2rem] aspect-[3/4]">
                <img 
                  src={service.image} 
                  alt={service.title} 
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                  referrerPolicy="no-referrer"
                />
              </div>
              <div className="flex items-center gap-3 mb-4">
                <div className="p-2 bg-ayurveda-olive/10 rounded-lg text-ayurveda-olive">
                  {service.icon}
                </div>
                <h3 className="text-2xl font-serif">{service.title}</h3>
              </div>
              <p className="text-ayurveda-ink/60 leading-relaxed">
                {service.description}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

const About = () => {
  return (
    <section id="about" className="py-24 bg-ayurveda-cream overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-20 items-center">
          <div className="relative">
            <img 
              src="https://picsum.photos/seed/ayurveda-about/800/800" 
              alt="Ayurvedic Herbs" 
              className="rounded-[3rem] shadow-xl"
              referrerPolicy="no-referrer"
            />
            <div className="absolute -bottom-10 -right-10 bg-ayurveda-terracotta text-white p-10 rounded-[2rem] hidden md:block">
              <p className="text-4xl font-serif mb-2">15+</p>
              <p className="text-sm uppercase tracking-widest opacity-80">Years of Healing</p>
            </div>
          </div>

          <div>
            <h2 className="text-4xl lg:text-5xl font-serif mb-8">The Wisdom of Life</h2>
            <div className="space-y-6 text-ayurveda-ink/70 leading-relaxed">
              <p>
                Ayurveda, which translates to "The Science of Life," is one of the world's oldest holistic healing systems. It was developed more than 3,000 years ago in India.
              </p>
              <p>
                At our clinic, we believe that health and wellness depend on a delicate balance between the mind, body, and spirit. Our mission is to guide you back to your natural state of equilibrium using time-tested principles.
              </p>
              <ul className="space-y-4 pt-4">
                {[
                  "Personalized Dosha-based treatments",
                  "Authentic Ayurvedic herbal remedies",
                  "Experienced practitioners and therapists",
                  "Serene and tranquil healing environment"
                ].map((item, i) => (
                  <li key={i} className="flex items-center gap-3">
                    <CheckCircle2 className="text-ayurveda-olive w-5 h-5" />
                    <span className="font-medium">{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

const Testimonials = () => {
  return (
    <section id="testimonials" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-serif">Healing Stories</h2>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {[
            {
              text: "The Panchakarma treatment completely transformed my energy levels. I feel like a new person both physically and mentally.",
              author: "Sarah Jenkins",
              role: "Yoga Instructor"
            },
            {
              text: "Authentic Ayurveda at its best. The practitioners are incredibly knowledgeable and the atmosphere is so peaceful.",
              author: "David Miller",
              role: "Software Engineer"
            },
            {
              text: "I've struggled with chronic stress for years. The personalized lifestyle plan has helped me find my center again.",
              author: "Elena Rodriguez",
              role: "Artist"
            }
          ].map((t, i) => (
            <div key={i} className="p-8 rounded-[2rem] bg-ayurveda-cream/50 border border-ayurveda-olive/5">
              <div className="flex gap-1 mb-6">
                {[...Array(5)].map((_, i) => <Star key={i} className="w-4 h-4 fill-ayurveda-terracotta text-ayurveda-terracotta" />)}
              </div>
              <p className="text-lg font-serif italic mb-8 leading-relaxed">"{t.text}"</p>
              <div>
                <p className="font-semibold">{t.author}</p>
                <p className="text-sm text-ayurveda-ink/50">{t.role}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

const Contact = () => {
  return (
    <section id="contact" className="py-24 bg-ayurveda-olive text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-20">
          <div>
            <h2 className="text-4xl lg:text-5xl font-serif mb-8">Begin Your Healing</h2>
            <p className="text-white/70 mb-12 leading-relaxed">
              Ready to take the first step towards holistic wellness? Contact us to schedule your initial consultation or to learn more about our treatments.
            </p>
            
            <div className="space-y-8">
              <div className="flex items-start gap-4">
                <div className="p-3 bg-white/10 rounded-xl">
                  <MapPin className="w-6 h-6" />
                </div>
                <div>
                  <p className="font-semibold mb-1">Our Sanctuary</p>
                  <p className="text-white/70">123 Healing Path, Serenity Valley<br />Wellness District, CA 90210</p>
                </div>
              </div>
              
              <div className="flex items-start gap-4">
                <div className="p-3 bg-white/10 rounded-xl">
                  <Phone className="w-6 h-6" />
                </div>
                <div>
                  <p className="font-semibold mb-1">Call Us</p>
                  <p className="text-white/70">+1 (555) 123-4567</p>
                </div>
              </div>
              
              <div className="flex items-start gap-4">
                <div className="p-3 bg-white/10 rounded-xl">
                  <Clock className="w-6 h-6" />
                </div>
                <div>
                  <p className="font-semibold mb-1">Opening Hours</p>
                  <p className="text-white/70">Mon - Sat: 8:00 AM - 7:00 PM<br />Sunday: Closed</p>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-white p-10 rounded-[2.5rem] text-ayurveda-ink">
            <h3 className="text-2xl font-serif mb-8">Request a Consultation</h3>
            <form className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium mb-2">First Name</label>
                  <input type="text" className="w-full px-4 py-3 rounded-xl border border-ayurveda-olive/10 focus:outline-none focus:ring-2 focus:ring-ayurveda-olive/20" placeholder="John" />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">Last Name</label>
                  <input type="text" className="w-full px-4 py-3 rounded-xl border border-ayurveda-olive/10 focus:outline-none focus:ring-2 focus:ring-ayurveda-olive/20" placeholder="Doe" />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">Email Address</label>
                <input type="email" className="w-full px-4 py-3 rounded-xl border border-ayurveda-olive/10 focus:outline-none focus:ring-2 focus:ring-ayurveda-olive/20" placeholder="john@example.com" />
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">Service of Interest</label>
                <select className="w-full px-4 py-3 rounded-xl border border-ayurveda-olive/10 focus:outline-none focus:ring-2 focus:ring-ayurveda-olive/20">
                  <option>Initial Consultation</option>
                  <option>Panchakarma Detox</option>
                  <option>Abhyanga Massage</option>
                  <option>Herbal Therapy</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">Message</label>
                <textarea className="w-full px-4 py-3 rounded-xl border border-ayurveda-olive/10 focus:outline-none focus:ring-2 focus:ring-ayurveda-olive/20 h-32" placeholder="Tell us about your wellness goals..."></textarea>
              </div>
              <button className="w-full bg-ayurveda-olive text-white py-4 rounded-xl font-medium hover:bg-ayurveda-olive/90 transition-all">
                Send Request
              </button>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
};

const Footer = () => {
  return (
    <footer className="py-12 bg-ayurveda-cream border-t border-ayurveda-olive/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row justify-between items-center gap-8">
          <div className="flex items-center gap-2">
            <Leaf className="text-ayurveda-olive w-6 h-6" />
            <span className="font-serif text-xl font-semibold">AyurVeda</span>
          </div>
          
          <div className="flex gap-8 text-sm font-medium text-ayurveda-ink/60">
            <a href="#" className="hover:text-ayurveda-olive transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-ayurveda-olive transition-colors">Terms of Service</a>
            <a href="#" className="hover:text-ayurveda-olive transition-colors">Cookie Policy</a>
          </div>
          
          <p className="text-sm text-ayurveda-ink/40">
            © {new Date().getFullYear()} AyurVeda Wellness Center. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default function App() {
  return (
    <div className="min-h-screen selection:bg-ayurveda-olive/20 selection:text-ayurveda-olive">
      <Navbar />
      <main>
        <Hero />
        <Services />
        <About />
        <Testimonials />
        <Contact />
      </main>
      <Footer />
    </div>
  );
}
